import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

const ChatQuerySchema = z.object({
  message: z.string().min(1),
});

function getConversationResponse(lowerMessage: string, holidayGreeting: string): any | null {
  // Greetings
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
    return {
      text: holidayGreeting + "Hello! I'm PMA Warrior, your school assistant. I can help you find locations around campus, information about staff members, or tell you about our school. What can I help you with today?",
      location: undefined,
      staff: undefined
    };
  }

  // How are you / feelings
  if (lowerMessage.includes('how are you') || lowerMessage.includes('how do you feel')) {
    return {
      text: holidayGreeting + "I'm doing great, thank you for asking! I'm here and ready to help you navigate PMA. Is there anything specific you'd like to know about the school?",
      location: undefined,
      staff: undefined
    };
  }

  // Weather (redirect to looking outside)
  if (lowerMessage.includes('weather') || lowerMessage.includes('temperature')) {
    return {
      text: holidayGreeting + "I don't have access to weather information, but you can always look outside or check your phone's weather app! Is there something about the school I can help you with instead?",
      location: undefined,
      staff: undefined
    };
  }

  // Time questions
  if (lowerMessage.includes('what time') || lowerMessage.includes('time is it')) {
    return {
      text: holidayGreeting + "I don't have access to the current time, but you can check your device's clock! If you're looking for school hours or class schedules, I can direct you to the main office for that information.",
      location: undefined,
      staff: undefined
    };
  }

  // Food/lunch questions
  if (lowerMessage.includes('lunch menu') || lowerMessage.includes('food today') || lowerMessage.includes('cafeteria menu')) {
    return {
      text: holidayGreeting + "I don't have access to today's lunch menu, but the cafeteria staff can tell you what's being served! You can also check with the main office for meal information.",
      location: undefined,
      staff: undefined
    };
  }

  // General help
  if (lowerMessage.includes('what can you do') || lowerMessage.includes('help me') || lowerMessage.includes('can you help')) {
    return {
      text: holidayGreeting + "I can help you with: finding locations around PMA (library, cafeteria, classrooms), getting information about staff members (principal, counselors, teachers), learning about our school's mission and values, and general school navigation. What would you like to know?",
      location: undefined,
      staff: undefined
    };
  }

  // Thank you
  if (lowerMessage.includes('thank you') || lowerMessage.includes('thanks')) {
    return {
      text: holidayGreeting + "You're very welcome! I'm always here to help PMA students. Feel free to ask me anything else about the school!",
      location: undefined,
      staff: undefined
    };
  }

  // Goodbye
  if (lowerMessage.includes('bye') || lowerMessage.includes('goodbye') || lowerMessage.includes('see you later')) {
    return {
      text: holidayGreeting + "Goodbye! Have a great day at PMA! Feel free to come back anytime you need help navigating the school.",
      location: undefined,
      staff: undefined
    };
  }

  // School pride/spirit and motto
  if (lowerMessage.includes('go warriors') || lowerMessage.includes('pma pride') || lowerMessage.includes('warrior pride') || lowerMessage.includes('motto')) {
    return {
      text: holidayGreeting + "Go Warriors! PMA pride runs strong! Our school community is built on the pillars of our motto – Pride, Virtue, Purpose. These values guide us to live authentically and reach our aspirations. Is there anything specific about PMA you'd like to know more about?",
      location: undefined,
      staff: undefined
    };
  }

  // Dress code questions with detailed information
  if (lowerMessage.includes('dress code') || lowerMessage.includes('uniform') || lowerMessage.includes('what to wear') || lowerMessage.includes('polo') || lowerMessage.includes('pants') || lowerMessage.includes('skirt')) {
    return {
      text: holidayGreeting + "PMA Dress Code Details:\n\n" +
        "STANDARD UNIFORM:\n" +
        "• Shirts: Official PMA polo (Red, White, Burgundy, Black, Grey)\n" +
        "• Pants: Black pants (must be hemmed, no jeans/skinny jeans/cargo)\n" +
        "• Skirts (women): Black or grey, must extend to top of knee\n" +
        "• Shorts: Black, hemmed to touch top of knee\n" +
        "• Shoes: Solid white, black, grey or crimson with closed toe/heel\n" +
        "• Socks: White or black, must be visible above ankle\n" +
        "• Belt (men): Black, must be worn and visible\n\n" +
        "IMPORTANT RULES:\n" +
        "• All uniform items must be purchased through Michael's Uniforms\n" +
        "• Students out of uniform may be denied class admission\n" +
        "• No gang-style alterations (grounds for expulsion)\n" +
        "• Administration is final interpreter of dress code\n\n" +
        "Contact main office (562) 861-2271 for questions.",
      location: undefined,
      staff: undefined
    };
  }

  // Attendance and absence questions with detailed policies
  if (lowerMessage.includes('absent') || lowerMessage.includes('sick') || lowerMessage.includes('attendance') || lowerMessage.includes('tardy') || lowerMessage.includes('late') || lowerMessage.includes('leave early')) {
    return {
      text: holidayGreeting + "PMA Attendance Policies:\n\n" +
        "ABSENCES:\n" +
        "• Parents must contact main office (562) 861-2271 for all absences\n" +
        "• Students must bring written excuse within 3 days of return\n" +
        "• Make-up work is allowed only for excused absences\n" +
        "• Extended absences (3+ days) require prior approval\n\n" +
        "TARDINESS:\n" +
        "• Students arriving after 8:15 AM are considered tardy\n" +
        "• Excessive tardiness may result in detention or loss of privileges\n\n" +
        "LEAVING EARLY:\n" +
        "• Students must be signed out by parent/guardian\n" +
        "• Early dismissal requires parent note or phone call\n\n" +
        "CLOSED CAMPUS:\n" +
        "• Students may not leave campus during school hours without permission\n\n" +
        "Contact main office (562) 861-2271 for specific situations.",
      location: undefined,
      staff: undefined
    };
  }

  // Academic questions with detailed information
  if (lowerMessage.includes('grades') || lowerMessage.includes('gpa') || lowerMessage.includes('graduation') || lowerMessage.includes('credits') || lowerMessage.includes('requirements') || lowerMessage.includes('transcript')) {
    return {
      text: holidayGreeting + "PMA Academic Information:\n\n" +
        "GRADUATION REQUIREMENTS:\n" +
        "• Complete all required academic units\n" +
        "• Maintain minimum GPA requirements\n" +
        "• Complete Christian Service Hours\n" +
        "• Pass all final examinations\n\n" +
        "GRADING:\n" +
        "• Uses both weighted and unweighted GPA\n" +
        "• Academic probation for GPA below 2.0\n" +
        "• Honor Roll recognition available\n" +
        "• Progress reports issued mid-quarter\n\n" +
        "ACADEMIC SUPPORT:\n" +
        "• Tutoring program available\n" +
        "• Academic guidance counseling\n" +
        "• Summer school options\n\n" +
        "For transcripts, detailed requirements, or academic counseling, contact main office (562) 861-2271.",
      location: undefined,
      staff: undefined
    };
  }

  // Sports and athletics questions
  if (lowerMessage.includes('sports') || lowerMessage.includes('athletics') || lowerMessage.includes('team') || lowerMessage.includes('coach')) {
    return {
      text: holidayGreeting + "PMA offers various athletic programs for Warriors! Students must meet eligibility requirements and maintain academic standards to participate. For information about specific sports, tryouts, or athletic policies, contact the main office at (562) 861-2271.",
      location: undefined,
      staff: undefined
    };
  }

  // Activities and clubs
  if (lowerMessage.includes('clubs') || lowerMessage.includes('activities') || lowerMessage.includes('extracurricular') || lowerMessage.includes('asb')) {
    return {
      text: holidayGreeting + "PMA has many co-curricular activities including ASB (Associated Student Body), clubs, and other extracurricular programs. Students must maintain eligibility requirements. For current club listings and how to join, contact the main office at (562) 861-2271.",
      location: undefined,
      staff: undefined
    };
  }

  // Tuition and financial questions
  if (lowerMessage.includes('tuition') || lowerMessage.includes('cost') || lowerMessage.includes('fees') || lowerMessage.includes('payment')) {
    return {
      text: holidayGreeting + "For information about tuition, fees, payment plans, or tuition assistance programs, please contact the main office directly at (562) 861-2271. They can provide current financial information and discuss available options.",
      location: undefined,
      staff: undefined
    };
  }

  // Cell phone and technology questions
  if (lowerMessage.includes('phone') || lowerMessage.includes('cell') || lowerMessage.includes('technology') || lowerMessage.includes('headphones') || lowerMessage.includes('devices')) {
    return {
      text: holidayGreeting + "PMA Cell Phone & Technology Policy:\n\n" +
        "CELL PHONES:\n" +
        "• Must be kept OFF and out of public view during school hours\n" +
        "• No picture taking unless teacher permission granted\n" +
        "• No harassment, threats, or inappropriate use\n" +
        "• Cannot be used for music, games, or food delivery services\n" +
        "• First violation: confiscation + warning\n" +
        "• Second violation: confiscation + $25 fee + detention\n" +
        "• Three+ violations: parent meeting required\n\n" +
        "HEADPHONES/EARBUDS:\n" +
        "• Not allowed throughout the day unless teacher permission\n\n" +
        "CONSEQUENCES:\n" +
        "• Devices can be confiscated by administration\n" +
        "• Parents called in emergency situations only\n\n" +
        "Contact main office (562) 861-2271 for questions.",
      location: undefined,
      staff: undefined
    };
  }

  // Staff directory searches
  if (lowerMessage.includes('principal') || lowerMessage.includes('claudia rodarte')) {
    return {
      text: holidayGreeting + `The Principal of St. Pius X – St. Matthias Academy is Claudia Rodarte '99.\n\nContact Information:\n• Location: Main Office\n• Phone: (562) 861-2271\n• Email: Contact through main office\n\nTo schedule a meeting with the principal, contact the main office at (562) 861-2271.`,
      location: undefined,
      staff: {
        name: "Claudia Rodarte '99",
        role: "Principal", 
        location: "Main Office",
        phone: "(562) 861-2271",
        email: "Contact through main office"
      }
    };
  }

  if (lowerMessage.includes('president') || lowerMessage.includes('christian de larkin')) {
    return {
      text: holidayGreeting + "President: Christian De Larkin. You can contact the main office at (562) 861-2271 to reach the president.",
      location: undefined,
      staff: {
        name: "Christian De Larkin",
        role: "President",
        location: "Administration",
        phone: "(562) 861-2271", 
        email: "Contact through main office"
      }
    };
  }

  if (lowerMessage.includes('counselor') || lowerMessage.includes('guidance')) {
    return {
      text: holidayGreeting + "PMA Counselors:\n• Lilian Valenzuela - Dean of Student Success, 9th & 10th Grade Counselor\n• Priscilla Contreras - 10th & 11th Grade Counselor  \n• Antonio Velarde - 12th Grade Counselor\n\nContact main office (562) 861-2271 to schedule counseling appointments.",
      location: undefined,
      staff: undefined
    };
  }

  if (lowerMessage.includes('athletics') || lowerMessage.includes('coach') || lowerMessage.includes('sports director')) {
    return {
      text: holidayGreeting + "Athletics Staff:\n• James Covell - Director of Athletics\n• Donte Archie - Assistant Director of Athletics, Boys' Basketball Head Coach\n• Scott Sovern - Boys Baseball Head Coach\n• Devah Thomas - Boys Football Head Coach\n• Sinnamonn Monroy - Girls Basketball Head Coach\n• Enrique Ortega - Boys Soccer Head Coach\n• Alicia Ross - Cross Country & Track Head Coach\n\nContact main office (562) 861-2271 for athletics information.",
      location: undefined,
      staff: undefined
    };
  }

  if (lowerMessage.includes('dean') || lowerMessage.includes('discipline')) {
    return {
      text: holidayGreeting + "Dean Staff:\n• Jordan Mitchell - Dean of Students\n• Aisling Serki - Dean of Faculty\n• Lilian Valenzuela - Dean of Student Success\n• Monique Saenz-Moreno - Dean of Academics\n• Gabriela Morales - Dean of Admissions & Marketing\n\nContact main office (562) 861-2271 to reach any dean.",
      location: undefined,
      staff: undefined
    };
  }

  // Teacher searches by department
  if (lowerMessage.includes('english teacher') || lowerMessage.includes('english department')) {
    return {
      text: holidayGreeting + "English Department:\n• Monique Saenz-Moreno - English Dept. Chair & Teacher\n• Celeste Avina - English Teacher\n• Kristine Martinez - English Teacher\n• Sarah Stucky - English Teacher\n• Colton Young - English Teacher\n\nContact main office (562) 861-2271 for teacher contact information.",
      location: undefined,
      staff: undefined
    };
  }

  if (lowerMessage.includes('math teacher') || lowerMessage.includes('mathematics')) {
    return {
      text: holidayGreeting + "Mathematics Department:\n• Annmarie Vanoy - Mathematics Department Head\n• Joseph Campos - Mathematics Teacher\n• Laura Fernandez - Mathematics Teacher\n• Sonia Hernandez - Mathematics Teacher\n\nContact main office (562) 861-2271 for teacher contact information.",
      location: undefined,
      staff: undefined
    };
  }

  if (lowerMessage.includes('science teacher') || lowerMessage.includes('science department')) {
    return {
      text: holidayGreeting + "Science Department:\n• German Diaz - Science Department Chair\n• Robert Pinedo - Science Teacher\n• Chef Rod Dodd - Nutritional Science & Agriculture Teacher\n\nContact main office (562) 861-2271 for teacher contact information.",
      location: undefined,
      staff: undefined
    };
  }

  if (lowerMessage.includes('theology') || lowerMessage.includes('religion')) {
    return {
      text: holidayGreeting + "Theology Department:\n• Katherine Lozano - Theology Dept. Chair & Teacher\n• Phillip Shifflet - Theology Teacher\n• Mary Frances Rutz '83 - Theology Teacher\n• Pete Ramos - Director of Faith & Leadership\n\nContact main office (562) 861-2271 for teacher contact information.",
      location: undefined,
      staff: undefined
    };
  }

  if (lowerMessage.includes('social science') || lowerMessage.includes('history')) {
    return {
      text: holidayGreeting + "Social Science Department:\n• Aisling Serki - Dean of Faculty, Social Science Teacher\n• Eric Lucas - Social Science Teacher\n• Javier Sanchez - Social Science Teacher\n\nContact main office (562) 861-2271 for teacher contact information.",
      location: undefined,
      staff: undefined
    };
  }

  if (lowerMessage.includes('world language') || lowerMessage.includes('spanish') || lowerMessage.includes('language')) {
    return {
      text: holidayGreeting + "World Language Department:\n• Yolanda Rosales - World Language Department Chair\n• Mayra Fernandez - World Language Teacher\n\nContact main office (562) 861-2271 for teacher contact information.",
      location: undefined,
      staff: undefined
    };
  }

  // Support staff and special programs
  if (lowerMessage.includes('attendance') || lowerMessage.includes('attendance clerk')) {
    return {
      text: holidayGreeting + "Attendance Clerk: Roxanne Santiago. For attendance questions, absences, or tardiness issues, contact the main office at (562) 861-2271.",
      location: undefined,
      staff: {
        name: "Roxanne Santiago",
        role: "Administration, Attendance Clerk",
        location: "Main Office",
        phone: "(562) 861-2271",
        email: "Contact through main office"
      }
    };
  }

  if (lowerMessage.includes('finance') || lowerMessage.includes('tuition') || lowerMessage.includes('billing')) {
    return {
      text: holidayGreeting + "Finance Staff:\n• Jose Barba - Director of Finance\n• Monica Barrera - Tuition Clerk\n\nFor tuition, billing, or financial questions, contact the main office at (562) 861-2271.",
      location: undefined,
      staff: undefined
    };
  }

  if (lowerMessage.includes('onward scholars') || lowerMessage.includes('special programs')) {
    return {
      text: holidayGreeting + "Special Programs:\n• Melissa Turcios '10 - Onward Scholars Director\n• Priscilla Contreras - Onward Scholars Director\n• Katie Pierce - Onward 2 High School Director\n\nContact main office (562) 861-2271 for program information.",
      location: undefined,
      staff: undefined
    };
  }

  if (lowerMessage.includes('theater') || lowerMessage.includes('theatre') || lowerMessage.includes('drama') || lowerMessage.includes('arts')) {
    return {
      text: holidayGreeting + "The School Theatre is connected to the gymnasium and cafeteria on the left side of campus. It's used for drama productions, arts performances, and school events.\n\nArts Programs:\n• Jonathan Sims - Theater Director\n• Gabriela Arreola '03 - Arts Collective Chair\n\nContact main office (562) 861-2271 for arts program information.",
      location: {
        name: "School Theatre",
        address: "Connected to Gymnasium and Cafeteria",
        hours: "Mon-Fri: 7:00 AM - 6:00 PM (during school events)",
        phone: "Contact main office",
        directions: "Located connected to the gymnasium and cafeteria on the left side. Access through the gym area or dedicated theatre entrance."
      },
      staff: undefined
    };
  }

  if (lowerMessage.includes('registrar') || lowerMessage.includes('enrollment') || lowerMessage.includes('admissions')) {
    return {
      text: holidayGreeting + "Enrollment & Admissions:\n• Gabriela Morales - Dean of Admissions & Marketing\n• Jocelyne Ramirez - Enrollment Coordinator, Registrar\n\nContact main office (562) 861-2271 for enrollment questions.",
      location: undefined,
      staff: undefined
    };
  }

  // Emergency and safety questions
  if (lowerMessage.includes('emergency') || lowerMessage.includes('safety') || lowerMessage.includes('earthquake') || lowerMessage.includes('lockdown')) {
    return {
      text: holidayGreeting + "PMA has comprehensive emergency procedures and safety protocols in place. Students receive regular emergency training including earthquake response plans. For specific safety information, contact the main office at (562) 861-2271.",
      location: undefined,
      staff: undefined
    };
  }

  // Community assembly questions
  if (lowerMessage.includes('community') || lowerMessage.includes('assembly') || lowerMessage.includes('morning assembly')) {
    return {
      text: holidayGreeting + "Community assemblies are held in the gymnasium, which is connected to the cafeteria and theatre on the left side of campus. These morning assemblies happen once or sometimes twice, bringing the whole school together as a community.",
      location: {
        name: "Gymnasium",
        address: "Connected to Cafeteria and Theatre",
        hours: "Mon-Fri: 7:00 AM - 6:00 PM",
        phone: "Ext. 4001",
        directions: "Located with cafeteria and theatre connections. This is where community assemblies are held."
      },
      staff: undefined
    };
  }

  // Cafeteria questions with updated connection info
  if (lowerMessage.includes('cafeteria') || lowerMessage.includes('lunch') || lowerMessage.includes('food') || lowerMessage.includes('dining')) {
    return {
      text: holidayGreeting + "The School Cafeteria is located connected to the gymnasium and theatre on the left side of campus. It serves breakfast and lunch and is part of the connected facility area.",
      location: {
        name: "School Cafeteria", 
        address: "Connected to Gymnasium",
        hours: "Mon-Fri: 7:00 AM - 2:00 PM",
        phone: "Ext. 3001",
        directions: "Located on the left side connected to the gym. From the main entrance, head towards the gymnasium area and look for the cafeteria entrance."
      },
      staff: undefined
    };
  }

  // Gym questions with updated assembly info
  if (lowerMessage.includes('gym') || lowerMessage.includes('gymnasium') || lowerMessage.includes('physical education') || lowerMessage.includes('pe')) {
    return {
      text: holidayGreeting + "The Gymnasium is connected to the cafeteria and theatre, and serves multiple purposes including physical education, sports events, and community assemblies. Morning assemblies are held here once or sometimes twice.",
      location: {
        name: "Gymnasium",
        address: "Connected to Cafeteria and Theatre", 
        hours: "Mon-Fri: 7:00 AM - 6:00 PM",
        phone: "Ext. 4001",
        directions: "Located with cafeteria and theatre connections. Accessible through the main corridor or outdoor entrance. This is where community assemblies are held."
      },
      staff: undefined
    };
  }

  // Jokes (redirect appropriately)
  if (lowerMessage.includes('tell me a joke') || lowerMessage.includes('joke')) {
    return {
      text: holidayGreeting + "I'm focused on helping you navigate PMA rather than telling jokes! But I'm sure you can find plenty of fun with your fellow Warriors around campus. What can I help you find today?",
      location: undefined,
      staff: undefined
    };
  }

  return null;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat endpoint
  app.post("/api/chat", async (req, res) => {
    let message = "";
    try {
      console.log("Raw request body:", req.body);
      const parsedBody = ChatQuerySchema.parse(req.body);
      message = parsedBody.message;
      console.log("Parsed message:", message);
      
      // Initialize response variable with default fallback
      let response: any = {
        text: "I'm sorry, but I can't answer that question at this time. However, the main office is open and the staff there can help you with any questions. You can contact the main office at (562) 861-2271 or visit them at St. Pius X – St. Matthias Academy, 7851 East Gardendale Street, Downey, CA 90242.",
        location: {
          name: "Main Office",
          address: "7851 East Gardendale Street, Downey, CA 90242",
          hours: "Contact main office for hours",
          phone: "(562) 861-2271",
          directions: "Main entrance of St. Pius X – St. Matthias Academy"
        },
        staff: undefined
      };
      
      // Check for holiday greetings based on current date
      const today = new Date();
      const month = today.getMonth() + 1; // JavaScript months are 0-indexed
      const day = today.getDate();
      
      let holidayGreeting = "";
      
      // Christmas Season
      if (month === 12 && day === 25) {
        holidayGreeting = "Merry Christmas! ";
      } else if (month === 12 && day >= 24 && day <= 26) {
        holidayGreeting = "Merry Christmas! ";
      }
      // New Year
      else if (month === 1 && day === 1) {
        holidayGreeting = "Happy New Year! ";
      }
      // Easter (approximate - varies each year, using typical March/April dates)
      else if ((month === 3 && day >= 20) || (month === 4 && day <= 25)) {
        const easterKeywords = ['easter', 'resurrection', 'palm sunday'];
        if (easterKeywords.some(keyword => message.toLowerCase().includes(keyword))) {
          holidayGreeting = "Happy Easter! ";
        }
      }
      // Valentine's Day
      else if (month === 2 && day === 14) {
        holidayGreeting = "Happy Valentine's Day! ";
      }
      // St. Patrick's Day
      else if (month === 3 && day === 17) {
        holidayGreeting = "Happy St. Patrick's Day! ";
      }
      // Halloween
      else if (month === 10 && day === 31) {
        holidayGreeting = "Happy Halloween! ";
      }
      // Thanksgiving (4th Thursday of November - approximate)
      else if (month === 11 && day >= 22 && day <= 28) {
        holidayGreeting = "Happy Thanksgiving! ";
      }
      // All Saints Day
      else if (month === 11 && day === 1) {
        holidayGreeting = "Happy All Saints Day! ";
      }
      // Independence Day
      else if (month === 7 && day === 4) {
        holidayGreeting = "Happy Independence Day! ";
      }
      // Labor Day (first Monday in September - approximate)
      else if (month === 9 && day >= 1 && day <= 7) {
        holidayGreeting = "Happy Labor Day! ";
      }

      // Update default response with holiday greeting
      response.text = holidayGreeting + response.text;

      // Check for academic cheating patterns first
      const academicPatterns = [
        /what is \d+[\+\-\*\/]\d+/,
        /solve for [xyz]/i,
        /find the derivative/i,
        /integrate/i,
        /what is the answer to/i,
        /homework/i,
        /assignment/i,
        /test answer/i,
        /quiz answer/i,
        /\d+[\+\-\*\/]\d+/,
        /calculate/i,
        /equation/i,
        /formula/i,
        /theorem/i,
        /proof/i
      ];

      const isAcademicQuestion = academicPatterns.some(pattern => pattern.test(message));
      
      if (isAcademicQuestion) {
        response = {
          text: holidayGreeting + "I can't help with homework or academic questions to maintain academic integrity. Please speak with your teacher or visit the main office for academic support. Contact the main office at (562) 861-2271 or visit St. Pius X – St. Matthias Academy at 7851 East Gardendale Street, Downey, CA 90242.",
          location: {
            name: "Main Office",
            address: "7851 East Gardendale Street, Downey, CA 90242",
            hours: "Contact main office for hours",
            phone: "(562) 861-2271",
            directions: "Main entrance of St. Pius X – St. Matthias Academy"
          },
          staff: undefined
        };
        
        await storage.createChatMessage({
          message,
          response: response.text,
          locationId: null,
          staffId: null
        });
        
        res.json(response);
        return;
      }

      // Simple keyword matching logic
      const lowerMessage = message.toLowerCase();

      // Check for specific school information queries (but not room locations)
      if (lowerMessage.includes('address') || lowerMessage.includes('school location') || lowerMessage.includes('where is the school') ||
          (lowerMessage === 'location') || (lowerMessage === 'where is pma') || (lowerMessage === 'where is the campus')) {
        response = {
          text: holidayGreeting + "St. Pius X – St. Matthias Academy is located at 7851 East Gardendale Street, Downey, California 90242. Main Office: (562) 861-2271. Our website is www.piusmatthias.org.",
          location: {
            name: "St. Pius X – St. Matthias Academy",
            address: "7851 East Gardendale Street, Downey, CA 90242",
            hours: "Contact main office for hours",
            phone: "(562) 861-2271",
            directions: "Located on East Gardendale Street in Downey"
          },
          staff: undefined
        };
        
        await storage.createChatMessage({
          message,
          response: response.text,
          locationId: null,
          staffId: null
        });
        
        res.json(response);
        return;
      }

      // Check for phone/contact information
      if (lowerMessage.includes('phone') || lowerMessage.includes('call') || lowerMessage.includes('contact')) {
        response = {
          text: holidayGreeting + "Main Office: (562) 861-2271. Fax: (562) 869-8652. You can also visit our website at www.piusmatthias.org or visit the main office at 7851 East Gardendale Street, Downey, CA.",
          location: {
            name: "Main Office",
            address: "7851 East Gardendale Street, Downey, CA 90242",
            hours: "Contact for office hours",
            phone: "(562) 861-2271",
            directions: "Main entrance of the school"
          },
          staff: undefined
        };
        
        await storage.createChatMessage({
          message,
          response: response.text,
          locationId: null,
          staffId: null
        });
        
        res.json(response);
        return;
      }

      // Check for PMA/school information queries (only specific school-related patterns)
      if (lowerMessage.includes('about pma') || lowerMessage.includes('about school') || 
          lowerMessage.includes('what is pma') || lowerMessage.includes('tell me about pma') || 
          lowerMessage.includes('tell me about the school') || lowerMessage.includes('about the school') ||
          lowerMessage.includes('about our school') || lowerMessage.includes('about this school') ||
          (lowerMessage === 'pma') || (lowerMessage === 'school') ||
          lowerMessage.includes('st. pius') || lowerMessage.includes('saint pius') ||
          lowerMessage.includes('st pius x') || lowerMessage.includes('st matthias') ||
          lowerMessage.includes('pius matthias academy')) {
        response = {
          text: holidayGreeting + "St. Pius X – St. Matthias Academy is the ideal home for all young adults yearning to be a part of a Catholic, academically rigorous, and spirited community. At PMA, we create opportunities for our students to discover, nurture, and share their gifts. St. Pius X – St. Matthias Academy allows our students to authentically learn and live out the pillars of our motto – Pride, Virtue, Purpose thus allowing them to move on to college and universities with a great sense of self and an even greater passion to live and reach their aspirations. We're located at 7851 East Gardendale Street, Downey, CA. Main Office: (562) 861-2271.",
          location: undefined,
          staff: undefined
        };
        
        // Store chat message and return early
        await storage.createChatMessage({
          message,
          response: response.text,
          locationId: null,
          staffId: null
        });
        
        res.json(response);
        return;
      }

      // Check for general conversation patterns first
      const conversationResponses = getConversationResponse(lowerMessage, holidayGreeting);
      if (conversationResponses) {
        response = conversationResponses;
        
        // Store conversation response message
        await storage.createChatMessage({
          message,
          response: response.text,
          locationId: null,
          staffId: null
        });
      } else {
        // Search for staff FIRST (before locations) to prioritize staff queries
        let staffMembers: any[] = [];
        if (lowerMessage.includes('principal')) {
          staffMembers = await storage.getAllStaff();
          staffMembers = staffMembers.filter(staff => staff.keywords.includes('principal'));
        } else if (lowerMessage.includes('counselor') || lowerMessage.includes('guidance')) {
          staffMembers = await storage.getAllStaff();
          staffMembers = staffMembers.filter(staff => staff.keywords.includes('counselor'));
        } else if (lowerMessage.includes('librarian')) {
          staffMembers = await storage.getAllStaff();
          staffMembers = staffMembers.filter(staff => staff.keywords.includes('librarian'));
        } else if (lowerMessage.includes('coach') || lowerMessage.includes('pe')) {
          staffMembers = await storage.getAllStaff();
          staffMembers = staffMembers.filter(staff => staff.keywords.includes('coach'));
        } else if (lowerMessage.includes('tell me about') || lowerMessage.includes('who is')) {
          // Handle specific staff name queries like "Tell me about Claudia Rodarte"
          staffMembers = await storage.getAllStaff();
          const nameQuery = lowerMessage.replace(/tell me about|who is|about/g, '').trim();
          console.log("Name query extracted:", nameQuery);
          staffMembers = staffMembers.filter(staff => 
            staff.name.toLowerCase().includes(nameQuery) ||
            staff.keywords.some((keyword: string) => nameQuery.includes(keyword))
          );
          console.log("Filtered staff members:", staffMembers.length);
        } else {
          staffMembers = await storage.searchStaff(lowerMessage);
        }
        
        if (staffMembers.length > 0) {
          const staff = staffMembers[0];
          
          // Enhanced principal response
          if (lowerMessage.includes('principal')) {
            response = {
              text: holidayGreeting + `The Principal of St. Pius X – St. Matthias Academy is ${staff.name}.\n\nContact Information:\n• Location: ${staff.location}\n• Phone: ${staff.phone}\n• Email: ${staff.email}\n\nTo schedule a meeting with the principal, contact the main office at (562) 861-2271.`,
              location: undefined,
              staff: {
                name: staff.name,
                role: staff.role,
                location: staff.location,
                phone: staff.phone || "No phone listed",
                email: staff.email || "No email listed"
              }
            };
          } else {
            // Standard staff response for other positions
            response = {
              text: holidayGreeting + `${staff.role}: ${staff.name}\n\nContact Information:\n• Location: ${staff.location}\n• Phone: ${staff.phone}\n• Email: ${staff.email}\n\nFor appointments or questions, contact the main office at (562) 861-2271.`,
              location: undefined,
              staff: {
                name: staff.name,
                role: staff.role,
                location: staff.location,
                phone: staff.phone || "No phone listed",
                email: staff.email || "No email listed"
              }
            };
          }
          
          // Store staff message
          await storage.createChatMessage({
            message,
            response: response.text,
            locationId: null,
            staffId: staff.id
          });
        } else {
          // Only check locations if no staff found
          let locations: any[] = [];
          
          // Check for room number queries first
          const roomMatch = lowerMessage.match(/room\s*(\d{3})|^(\d{3})$|(\d{3})/);
          if (roomMatch) {
            const roomNumber = roomMatch[1] || roomMatch[2] || roomMatch[3];
            
            // Enhanced room data with specific descriptions and wing information
            const roomData: any = {
              // 1st Floor Odd Wing
              '101': { description: 'Main Office & Principal\'s Office', wing: 'odd wing on the first floor of the main building' },
              '103': { description: 'Classroom', wing: 'odd wing on the first floor of the main building' },
              '105': { description: 'Classroom', wing: 'odd wing on the first floor of the main building' },
              '107': { description: 'Classroom', wing: 'odd wing on the first floor of the main building' },
              '109': { description: 'Classroom', wing: 'odd wing on the first floor of the main building' },
              '111': { description: 'Classroom', wing: 'odd wing on the first floor of the main building' },
              '113': { description: 'Classroom', wing: 'odd wing on the first floor of the main building' },
              '115': { description: 'Nurse\'s Office', wing: 'odd wing on the first floor of the main building' },
              '117': { description: 'Classroom', wing: 'odd wing on the first floor of the main building' },
              '119': { description: 'Classroom', wing: 'odd wing on the first floor of the main building' },
              '121': { description: 'Computer Lab', wing: 'odd wing on the first floor of the main building' },
              '123': { description: 'Classroom', wing: 'odd wing on the first floor of the main building' },
              
              // 1st Floor Even Wing
              '102': { description: 'Classroom', wing: 'even wing on the first floor of the main building' },
              '104': { description: 'Classroom', wing: 'even wing on the first floor of the main building' },
              '106': { description: 'Classroom', wing: 'even wing on the first floor of the main building' },
              '108': { description: 'Classroom', wing: 'even wing on the first floor of the main building' },
              '110': { description: 'Counseling Office', wing: 'even wing on the first floor of the main building' },
              '112': { description: 'Classroom', wing: 'even wing on the first floor of the main building' },
              '114': { description: 'Classroom', wing: 'even wing on the first floor of the main building' },
              '116': { description: 'Science Lab', wing: 'even wing on the first floor of the main building' },
              '118': { description: 'Classroom', wing: 'even wing on the first floor of the main building' },
              '120': { description: 'Classroom', wing: 'even wing on the first floor of the main building' },
              '122': { description: 'Art Room', wing: 'even wing on the first floor of the main building' },
              '124': { description: 'Classroom', wing: 'even wing on the first floor of the main building' },
              
              // 2nd Floor Odd Wing
              '201': { description: 'Classroom', wing: 'odd wing on the second floor of the main building' },
              '203': { description: 'Classroom', wing: 'odd wing on the second floor of the main building' },
              '205': { description: 'Classroom', wing: 'odd wing on the second floor of the main building' },
              '207': { description: 'Classroom', wing: 'odd wing on the second floor of the main building' },
              '209': { description: 'Classroom', wing: 'odd wing on the second floor of the main building' },
              '211': { description: 'Classroom', wing: 'odd wing on the second floor of the main building' },
              '213': { description: 'Science Lab', wing: 'odd wing on the second floor of the main building' },
              '215': { description: 'Classroom', wing: 'odd wing on the second floor of the main building' },
              '217': { description: 'Classroom', wing: 'odd wing on the second floor of the main building' },
              '219': { description: 'Computer Lab', wing: 'odd wing on the second floor of the main building' },
              '221': { description: 'Classroom', wing: 'odd wing on the second floor of the main building' },
              '223': { description: 'Classroom', wing: 'odd wing on the second floor of the main building' },
              
              // 2nd Floor Even Wing
              '202': { description: 'Classroom', wing: 'even wing on the second floor of the main building' },
              '204': { description: 'Classroom', wing: 'even wing on the second floor of the main building' },
              '206': { description: 'Classroom', wing: 'even wing on the second floor of the main building' },
              '208': { description: 'Classroom', wing: 'even wing on the second floor of the main building' },
              '210': { description: 'Classroom', wing: 'even wing on the second floor of the main building' },
              '212': { description: 'Classroom', wing: 'even wing on the second floor of the main building' },
              '214': { description: 'Science Lab', wing: 'even wing on the second floor of the main building' },
              '216': { description: 'Classroom', wing: 'even wing on the second floor of the main building' },
              '218': { description: 'Classroom', wing: 'even wing on the second floor of the main building' },
              '220': { description: 'Classroom', wing: 'even wing on the second floor of the main building' },
              '222': { description: 'Faculty Office', wing: 'even wing on the second floor of the main building' },
              '224': { description: 'Storage/Resource Room', wing: 'even wing on the second floor of the main building' }
            };

            if (roomData[roomNumber]) {
              const room = roomData[roomNumber];
              const floorText = roomNumber.startsWith('1') ? 'first floor' : 'second floor';
              const wingText = parseInt(roomNumber) % 2 === 1 ? 'odd wing' : 'even wing';
              const directionsText = `Enter main building, ${floorText === 'first floor' ? 'first floor' : 'go to second floor'}, ${wingText}, room ${roomNumber}`;
              
              response = {
                text: holidayGreeting + `The Room ${roomNumber} is located in Main Building, on the ${floorText === 'first floor' ? '1st' : '2nd'} Floor, ${roomNumber}. ${room.description} in the ${room.wing}`,
                location: {
                  name: `Room ${roomNumber}`,
                  address: `Main Building, ${floorText === 'first floor' ? '1st' : '2nd'} Floor, ${roomNumber}`,
                  hours: "School hours",
                  phone: "Contact main office",
                  directions: directionsText
                },
                staff: undefined
              };
              
              // Store room message
              await storage.createChatMessage({
                message,
                response: response.text,
                locationId: null,
                staffId: null
              });
            } else {
              // Fallback for rooms not in our enhanced data
              locations = await storage.getAllLocations();
              locations = locations.filter(loc => 
                loc.room === roomNumber || 
                loc.keywords.includes(roomNumber) ||
                loc.keywords.includes(`room ${roomNumber}`)
              );
            }
          }
          // Check for specific location types
          else if (lowerMessage.includes('library')) {
            locations = await storage.getAllLocations();
            locations = locations.filter(loc => loc.keywords.includes('library'));
          } else if (lowerMessage.includes('cafeteria') || lowerMessage.includes('lunch') || lowerMessage.includes('food')) {
            locations = await storage.getAllLocations();
            locations = locations.filter(loc => loc.keywords.includes('cafeteria'));
          } else if (lowerMessage.includes('gym') || lowerMessage.includes('gymnasium')) {
            locations = await storage.getAllLocations();
            locations = locations.filter(loc => loc.keywords.includes('gym'));
          } else if (lowerMessage.includes('office') || lowerMessage.includes('main office')) {
            locations = await storage.getAllLocations();
            locations = locations.filter(loc => loc.keywords.includes('office'));
          } else if (lowerMessage.includes('nurse')) {
            locations = await storage.getAllLocations();
            locations = locations.filter(loc => loc.keywords.includes('nurse'));
          } else {
            locations = await storage.searchLocations(lowerMessage);
          }

          if (locations.length > 0) {
            const location = locations[0];
            response = {
              text: holidayGreeting + `The ${location.name} is located in ${location.building}${location.floor ? `, on the ${location.floor}` : ''}${location.room ? `, ${location.room}` : ''}. ${location.description || ''}`,
              location: {
                name: location.name,
                address: `${location.building}${location.floor ? `, ${location.floor}` : ''}${location.room ? `, ${location.room}` : ''}`,
                hours: location.hours || "Contact for hours",
                phone: location.phone || "No phone listed",
                directions: location.directions
              },
              staff: undefined
            };
            
            // Store location message
            await storage.createChatMessage({
              message,
              response: response.text,
              locationId: location.id,
              staffId: null
            });
          } else {
            // No specific match, store default message
            await storage.createChatMessage({
              message,
              response: response.text,
              locationId: null,
              staffId: null
            });
          }
        }
      }

      res.json(response);
    } catch (error) {
      console.error("API Error details:", error);
      console.error("Error stack:", error instanceof Error ? error.stack : error);
      console.error("Message being processed:", message);
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Get all staff
  app.get("/api/staff", async (req, res) => {
    try {
      const staff = await storage.getAllStaff();
      res.json(staff);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch staff" });
    }
  });

  // Search staff
  app.get("/api/staff/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        const allStaff = await storage.getAllStaff();
        res.json(allStaff);
        return;
      }
      
      const staff = await storage.searchStaff(query);
      res.json(staff);
    } catch (error) {
      res.status(500).json({ message: "Failed to search staff" });
    }
  });

  // Get all locations
  app.get("/api/locations", async (req, res) => {
    try {
      const locations = await storage.getAllLocations();
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch locations" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
