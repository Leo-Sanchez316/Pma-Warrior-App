import { 
  users, 
  locations, 
  staff, 
  chatMessages,
  type User, 
  type InsertUser,
  type Location,
  type InsertLocation,
  type Staff,
  type InsertStaff,
  type ChatMessage,
  type InsertChatMessage
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllLocations(): Promise<Location[]>;
  getLocationById(id: number): Promise<Location | undefined>;
  searchLocations(query: string): Promise<Location[]>;
  createLocation(location: InsertLocation): Promise<Location>;
  
  getAllStaff(): Promise<Staff[]>;
  getStaffById(id: number): Promise<Staff | undefined>;
  searchStaff(query: string): Promise<Staff[]>;
  createStaff(staff: InsertStaff): Promise<Staff>;
  
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getChatHistory(): Promise<ChatMessage[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private locations: Map<number, Location>;
  private staff: Map<number, Staff>;
  private chatMessages: Map<number, ChatMessage>;
  private currentUserId: number;
  private currentLocationId: number;
  private currentStaffId: number;
  private currentChatId: number;

  constructor() {
    this.users = new Map();
    this.locations = new Map();
    this.staff = new Map();
    this.chatMessages = new Map();
    this.currentUserId = 1;
    this.currentLocationId = 1;
    this.currentStaffId = 1;
    this.currentChatId = 1;
    
    this.seedData();
  }

  private seedData() {
    // Seed locations
    const sampleLocations: InsertLocation[] = [
      {
        name: "School Library",
        building: "Building B",
        floor: "2nd Floor",
        room: "Room 201",
        description: "Main school library with books, computers, and study areas",
        hours: "Mon-Fri: 7:30 AM - 5:00 PM",
        phone: "Ext. 2201",
        directions: "From the main entrance, take the stairs or elevator in Building B to the second floor. The library will be on your right.",
        keywords: ["library", "books", "study", "research", "computer", "quiet"]
      },
      {
        name: "School Cafeteria",
        building: "Building C",
        floor: "1st Floor",
        room: "",
        description: "Main dining area serving breakfast and lunch",
        hours: "Mon-Fri: 7:00 AM - 2:00 PM",
        phone: "Ext. 3001",
        directions: "From the main entrance, head towards Building C. The cafeteria entrance is clearly marked with large signs.",
        keywords: ["cafeteria", "lunch", "food", "dining", "eat", "breakfast"]
      },
      {
        name: "Main Office",
        building: "Building A",
        floor: "1st Floor",
        room: "Room 101",
        description: "Administrative offices and principal's office",
        hours: "Mon-Fri: 8:00 AM - 4:00 PM",
        phone: "Ext. 1001",
        directions: "Located at the main entrance of Building A, immediately to your right as you enter.",
        keywords: ["office", "administration", "principal", "secretary", "forms"]
      },
      {
        name: "Gymnasium",
        building: "Building D",
        floor: "1st Floor",
        room: "",
        description: "Main gym for physical education and sports events",
        hours: "Mon-Fri: 7:00 AM - 6:00 PM",
        phone: "Ext. 4001",
        directions: "Located in Building D, accessible through the main corridor or outdoor entrance.",
        keywords: ["gym", "gymnasium", "sports", "basketball", "physical education", "pe"]
      },
      {
        name: "Nurse's Office",
        building: "Building A",
        floor: "1st Floor",
        room: "Room 115",
        description: "School health office for medical needs",
        hours: "Mon-Fri: 8:00 AM - 3:30 PM",
        phone: "Ext. 1115",
        directions: "Located in Building A, near the main office. Look for the red cross sign.",
        keywords: ["nurse", "health", "medical", "sick", "injury", "medicine"]
      }
    ];

    sampleLocations.forEach(location => {
      const id = this.currentLocationId++;
      this.locations.set(id, { ...location, id });
    });

    // Seed PMA staff
    const pmaStaff: InsertStaff[] = [
      {
        name: "Claudia Rodarte '99",
        role: "Principal",
        location: "Main Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["principal", "administrator", "head", "leader", "claudia", "rodarte"]
      },
      {
        name: "Christian De Larkin",
        role: "President",
        location: "Administration",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["president", "administration", "christian", "larkin"]
      },
      {
        name: "Jordan Mitchell",
        role: "Dean of Students",
        location: "Administration",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["dean", "students", "discipline", "jordan", "mitchell"]
      },
      {
        name: "Lilian Valenzuela",
        role: "Dean of Student Success, 9th & 10th Grade Counselor",
        location: "Counseling Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["counselor", "guidance", "dean", "success", "9th", "10th", "lilian", "valenzuela"]
      },
      {
        name: "Antonio Velarde",
        role: "12th Grade Counselor",
        location: "Counseling Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["counselor", "guidance", "12th", "senior", "antonio", "velarde"]
      },
      {
        name: "Priscilla Contreras",
        role: "10th & 11th Grade Counselor, Onward Scholars Director",
        location: "Counseling Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["counselor", "guidance", "10th", "11th", "onward", "scholars", "priscilla", "contreras"]
      },
      {
        name: "James Covell",
        role: "Director of Athletics",
        location: "Athletics Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["athletics", "director", "sports", "coach", "james", "covell"]
      },
      {
        name: "Donte Archie",
        role: "Assistant Director of Athletics, Boys' Basketball Head Coach",
        location: "Athletics Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["athletics", "basketball", "coach", "boys", "donte", "archie"]
      },
      {
        name: "Monique Saenz-Moreno",
        role: "Dean of Academics, English Dept. Chair & Teacher",
        location: "English Department",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["dean", "academics", "english", "teacher", "department", "chair", "monique", "saenz", "moreno"]
      },
      {
        name: "Annmarie Vanoy",
        role: "Mathematics Department Head",
        location: "Mathematics Department",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["mathematics", "math", "department", "head", "teacher", "annmarie", "vanoy"]
      },
      {
        name: "German Diaz",
        role: "Science Department Chair",
        location: "Science Department",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["science", "department", "chair", "teacher", "german", "diaz"]
      },
      {
        name: "Katherine Lozano",
        role: "Theology Dept. Chair & Teacher",
        location: "Theology Department",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["theology", "religion", "department", "chair", "teacher", "katherine", "lozano"]
      },
      {
        name: "Yolanda Rosales",
        role: "World Language Department Chair",
        location: "World Language Department",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["world", "language", "spanish", "department", "chair", "teacher", "yolanda", "rosales"]
      },
      {
        name: "Roxanne Santiago",
        role: "Administration, Attendance Clerk",
        location: "Main Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["attendance", "clerk", "administration", "absence", "tardy", "roxanne", "santiago"]
      },
      {
        name: "Jose Barba",
        role: "Director of Finance",
        location: "Finance Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["finance", "director", "tuition", "billing", "money", "jose", "barba"]
      },
      {
        name: "Gabriela Morales",
        role: "Dean of Admissions & Marketing",
        location: "Admissions Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["admissions", "marketing", "dean", "enrollment", "gabriela", "morales"]
      }
    ];

    pmaStaff.forEach(staffMember => {
      const id = this.currentStaffId++;
      this.staff.set(id, { ...staffMember, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllLocations(): Promise<Location[]> {
    return Array.from(this.locations.values());
  }

  async getLocationById(id: number): Promise<Location | undefined> {
    return this.locations.get(id);
  }

  async searchLocations(query: string): Promise<Location[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.locations.values()).filter(location => {
      // Check if any keyword appears in the query
      return location.keywords.some(keyword => 
        lowerQuery.includes(keyword.toLowerCase())
      ) || 
      // Check if location name appears in query
      lowerQuery.includes(location.name.toLowerCase()) ||
      // Check if query appears in location name or description
      location.name.toLowerCase().includes(lowerQuery) ||
      location.description?.toLowerCase().includes(lowerQuery);
    });
  }

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const id = this.currentLocationId++;
    const location: Location = { ...insertLocation, id };
    this.locations.set(id, location);
    return location;
  }

  async getAllStaff(): Promise<Staff[]> {
    return Array.from(this.staff.values());
  }

  async getStaffById(id: number): Promise<Staff | undefined> {
    return this.staff.get(id);
  }

  async searchStaff(query: string): Promise<Staff[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.staff.values()).filter(staff =>
      staff.name.toLowerCase().includes(lowerQuery) ||
      staff.role.toLowerCase().includes(lowerQuery) ||
      staff.keywords.some(keyword => lowerQuery.includes(keyword.toLowerCase()))
    );
  }

  async createStaff(insertStaff: InsertStaff): Promise<Staff> {
    const id = this.currentStaffId++;
    const staff: Staff = { ...insertStaff, id };
    this.staff.set(id, staff);
    return staff;
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentChatId++;
    const message: ChatMessage = { ...insertMessage, id };
    this.chatMessages.set(id, message);
    return message;
  }

  async getChatHistory(): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values());
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllLocations(): Promise<Location[]> {
    return await db.select().from(locations);
  }

  async getLocationById(id: number): Promise<Location | undefined> {
    const [location] = await db.select().from(locations).where(eq(locations.id, id));
    return location || undefined;
  }

  async searchLocations(query: string): Promise<Location[]> {
    const lowerQuery = query.toLowerCase();
    const allLocations = await db.select().from(locations);
    return allLocations.filter(location => {
      return location.keywords.some(keyword => 
        lowerQuery.includes(keyword.toLowerCase())
      ) || 
      lowerQuery.includes(location.name.toLowerCase()) ||
      location.name.toLowerCase().includes(lowerQuery) ||
      location.description?.toLowerCase().includes(lowerQuery);
    });
  }

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const [location] = await db
      .insert(locations)
      .values(insertLocation)
      .returning();
    return location;
  }

  async getAllStaff(): Promise<Staff[]> {
    return await db.select().from(staff);
  }

  async getStaffById(id: number): Promise<Staff | undefined> {
    const [staffMember] = await db.select().from(staff).where(eq(staff.id, id));
    return staffMember || undefined;
  }

  async searchStaff(query: string): Promise<Staff[]> {
    const lowerQuery = query.toLowerCase();
    const allStaff = await db.select().from(staff);
    return allStaff.filter(staffMember =>
      staffMember.name.toLowerCase().includes(lowerQuery) ||
      staffMember.role.toLowerCase().includes(lowerQuery) ||
      staffMember.keywords.some(keyword => lowerQuery.includes(keyword.toLowerCase()))
    );
  }

  async createStaff(insertStaff: InsertStaff): Promise<Staff> {
    const [staffMember] = await db
      .insert(staff)
      .values(insertStaff)
      .returning();
    return staffMember;
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const [message] = await db
      .insert(chatMessages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async getChatHistory(): Promise<ChatMessage[]> {
    return await db.select().from(chatMessages);
  }
}

export const storage = new DatabaseStorage();
