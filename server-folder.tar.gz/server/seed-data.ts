import { db } from "./db";
import { locations, staff } from "@shared/schema";

export async function seedDatabase() {
  try {
    // Check if data already exists
    const existingLocations = await db.select().from(locations);
    if (existingLocations.length > 0) {
      console.log("Database already seeded");
      return;
    }

    // Seed authentic room locations from school maps
    const sampleLocations = [
      // Odd wing, first floor
      {
        name: "Campus Ministry Center",
        building: "Main Building",
        floor: "1st Floor",
        room: "Room 131",
        description: "Campus ministry center for spiritual activities and counseling",
        hours: "School hours",
        phone: "Contact main office",
        directions: "Enter main building, first floor, odd wing, room 131",
        keywords: ["campus", "ministry", "spiritual", "131", "prayer", "chaplain"]
      },
      {
        name: "CPLA Office",
        building: "Main Building", 
        floor: "1st Floor",
        room: "Room 123",
        description: "CPLA office for academic support and programs",
        hours: "School hours",
        phone: "Contact main office",
        directions: "Enter main building, first floor, odd wing, room 123",
        keywords: ["cpla", "123", "academic", "support", "programs"]
      },
      {
        name: "Ceramics Studio",
        building: "Main Building",
        floor: "1st Floor", 
        room: "Room 115",
        description: "Ceramics studio for art classes and pottery",
        hours: "School hours",
        phone: "Contact main office",
        directions: "Enter main building, first floor, odd wing, room 115",
        keywords: ["ceramics", "115", "art", "pottery", "studio", "clay"]
      },
      {
        name: "Art Gallery",
        building: "Main Building",
        floor: "1st Floor",
        room: null,
        description: "Student art gallery showcasing creative works",
        hours: "School hours",
        phone: "Contact main office", 
        directions: "Located in the odd wing on the first floor of the main building",
        keywords: ["art", "gallery", "exhibition", "artwork", "display"]
      },
      {
        name: "Activities Center",
        building: "Main Building",
        floor: "1st Floor",
        room: "Room 113", 
        description: "Activities center for student organizations and events",
        hours: "School hours",
        phone: "Contact main office",
        directions: "Enter main building, first floor, odd wing, room 113",
        keywords: ["activities", "113", "student", "organizations", "events", "clubs"]
      },
      {
        name: "President's Office",
        building: "Main Building",
        floor: "1st Floor",
        room: null,
        description: "Office of the school president",
        hours: "By appointment",
        phone: "Contact main office",
        directions: "Located in the odd wing on the first floor of the main building",
        keywords: ["president", "office", "administration", "executive"]
      },
      // Even wing, first floor
      {
        name: "Main Office",
        building: "Main Building",
        floor: "1st Floor", 
        room: null,
        description: "Main administrative office and reception",
        hours: "Mon-Fri: 8:00 AM - 4:00 PM",
        phone: "(562) 861-2271",
        directions: "Located at the main entrance in the even wing on the first floor",
        keywords: ["main", "office", "administration", "reception", "secretary"]
      },
      {
        name: "Esports Room",
        building: "Main Building",
        floor: "1st Floor",
        room: null,
        description: "Esports gaming room for competitive gaming teams",
        hours: "School hours",
        phone: "Contact main office",
        directions: "Located in the even wing on the first floor of the main building",
        keywords: ["esports", "gaming", "computer", "competitive", "teams"]
      },
      {
        name: "Student Store",
        building: "Main Building",
        floor: "1st Floor",
        room: null,
        description: "Student store selling school supplies and merchandise",
        hours: "School hours",
        phone: "Contact main office",
        directions: "Located in the even wing on the first floor of the main building", 
        keywords: ["student", "store", "supplies", "merchandise", "books", "uniforms"]
      },
      {
        name: "Athletics Center",
        building: "Main Building",
        floor: "1st Floor",
        room: null,
        description: "Athletics center and coaching offices",
        hours: "School hours",
        phone: "Contact main office",
        directions: "Located in the even wing on the first floor of the main building",
        keywords: ["athletics", "sports", "coaching", "teams", "physical"]
      },
      {
        name: "Dean of Student Body Office",
        building: "Main Building",
        floor: "1st Floor",
        room: null,
        description: "Dean of student body office for student affairs",
        hours: "School hours", 
        phone: "Contact main office",
        directions: "Located in the even wing on the first floor of the main building",
        keywords: ["dean", "student", "body", "affairs", "discipline"]
      },
      {
        name: "Principal's Office",
        building: "Main Building",
        floor: "1st Floor",
        room: null,
        description: "Principal's office for school administration",
        hours: "By appointment",
        phone: "(562) 861-2271",
        directions: "Located in the even wing on the first floor of the main building",
        keywords: ["principal", "office", "administration", "head"]
      },
      {
        name: "PLC Room",
        building: "Main Building",
        floor: "1st Floor",
        room: null,
        description: "Professional Learning Community room for staff meetings",
        hours: "Staff hours",
        phone: "Contact main office",
        directions: "Located in the even wing on the first floor of the main building",
        keywords: ["plc", "professional", "learning", "community", "staff", "meetings"]
      },
      {
        name: "College Center",
        building: "Main Building",
        floor: "1st Floor",
        room: null,
        description: "College counseling and guidance center",
        hours: "School hours",
        phone: "Contact main office",
        directions: "Located in the even wing on the first floor of the main building", 
        keywords: ["college", "counseling", "guidance", "university", "applications"]
      },
      {
        name: "School Cafeteria",
        building: "Connected to Gymnasium",
        floor: "1st Floor",
        room: null,
        description: "Main dining area serving breakfast and lunch, connected to the theatre and gymnasium",
        hours: "Mon-Fri: 7:00 AM - 2:00 PM",
        phone: "Ext. 3001",
        directions: "Located on the left side connected to the gym. From the main entrance, head towards the gymnasium area and look for the cafeteria entrance.",
        keywords: ["cafeteria", "lunch", "food", "dining", "eat", "breakfast"]
      },
      {
        name: "Main Office",
        building: "Building A",
        floor: "1st Floor",
        room: "Room 101",
        description: "Administrative offices and principal's office",
        hours: "Mon-Fri: 8:00 AM - 4:00 PM",
        phone: "Ext. 1001",
        directions: "Located at the main entrance of Building A, immediately to your right as you enter.",
        keywords: ["office", "administration", "principal", "secretary", "forms"]
      },
      {
        name: "Gymnasium",
        building: "Connected to Cafeteria and Theatre",
        floor: "1st Floor",
        room: null,
        description: "Main gym for physical education, sports events, and morning community assemblies. Connected to the cafeteria and theatre.",
        hours: "Mon-Fri: 7:00 AM - 6:00 PM",
        phone: "Ext. 4001",
        directions: "Located with cafeteria and theatre connections. Accessible through the main corridor or outdoor entrance. This is where community assemblies are held.",
        keywords: ["gym", "gymnasium", "sports", "basketball", "physical education", "pe", "community", "assembly", "morning assembly"]
      },
      {
        name: "Nurse's Office",
        building: "Building A",
        floor: "1st Floor",
        room: "Room 115",
        description: "School health office for medical needs",
        hours: "Mon-Fri: 8:00 AM - 3:30 PM",
        phone: "Ext. 1115",
        directions: "Located in Building A, near the main office. Look for the red cross sign.",
        keywords: ["nurse", "health", "medical", "sick", "injury", "medicine"]
      },
      {
        name: "School Theatre",
        building: "Connected to Gymnasium and Cafeteria",
        floor: "1st Floor",
        room: null,
        description: "School theatre for drama productions, arts performances, and school events. Connected to the gymnasium and cafeteria.",
        hours: "Mon-Fri: 7:00 AM - 6:00 PM (during school events)",
        phone: "Contact main office",
        directions: "Located connected to the gymnasium and cafeteria on the left side. Access through the gym area or dedicated theatre entrance.",
        keywords: ["theatre", "theater", "drama", "performance", "arts", "stage", "play", "musical"]
      }
    ];

    await db.insert(locations).values(sampleLocations);

    // Seed PMA staff
    const pmaStaff = [
      {
        name: "Claudia Rodarte '99",
        role: "Principal",
        location: "Main Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["principal", "administrator", "head", "leader", "claudia", "rodarte"]
      },
      {
        name: "Christian De Larkin",
        role: "President",
        location: "Administration",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["president", "administration", "christian", "larkin"]
      },
      {
        name: "Jordan Mitchell",
        role: "Dean of Students",
        location: "Administration",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["dean", "students", "discipline", "jordan", "mitchell"]
      },
      {
        name: "Lilian Valenzuela",
        role: "Dean of Student Success, 9th & 10th Grade Counselor",
        location: "Counseling Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["counselor", "guidance", "dean", "success", "9th", "10th", "lilian", "valenzuela"]
      },
      {
        name: "Antonio Velarde",
        role: "12th Grade Counselor",
        location: "Counseling Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["counselor", "guidance", "12th", "senior", "antonio", "velarde"]
      },
      {
        name: "Priscilla Contreras",
        role: "10th & 11th Grade Counselor, Onward Scholars Director",
        location: "Counseling Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["counselor", "guidance", "10th", "11th", "onward", "scholars", "priscilla", "contreras"]
      },
      {
        name: "James Covell",
        role: "Director of Athletics",
        location: "Athletics Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["athletics", "director", "sports", "coach", "james", "covell"]
      },
      {
        name: "Donte Archie",
        role: "Assistant Director of Athletics, Boys' Basketball Head Coach",
        location: "Athletics Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["athletics", "basketball", "coach", "boys", "donte", "archie"]
      },
      {
        name: "Monique Saenz-Moreno",
        role: "Dean of Academics, English Dept. Chair & Teacher",
        location: "English Department",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["dean", "academics", "english", "teacher", "department", "chair", "monique", "saenz", "moreno"]
      },
      {
        name: "Annmarie Vanoy",
        role: "Mathematics Department Head",
        location: "Mathematics Department",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["mathematics", "math", "department", "head", "teacher", "annmarie", "vanoy"]
      },
      {
        name: "German Diaz",
        role: "Science Department Chair",
        location: "Science Department",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["science", "department", "chair", "teacher", "german", "diaz"]
      },
      {
        name: "Katherine Lozano",
        role: "Theology Dept. Chair & Teacher",
        location: "Theology Department",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["theology", "religion", "department", "chair", "teacher", "katherine", "lozano"]
      },
      {
        name: "Yolanda Rosales",
        role: "World Language Department Chair",
        location: "World Language Department",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["world", "language", "spanish", "department", "chair", "teacher", "yolanda", "rosales"]
      },
      {
        name: "Roxanne Santiago",
        role: "Administration, Attendance Clerk",
        location: "Main Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["attendance", "clerk", "administration", "absence", "tardy", "roxanne", "santiago"]
      },
      {
        name: "Jose Barba",
        role: "Director of Finance",
        location: "Finance Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["finance", "director", "tuition", "billing", "money", "jose", "barba"]
      },
      {
        name: "Gabriela Morales",
        role: "Dean of Admissions & Marketing",
        location: "Admissions Office",
        phone: "(562) 861-2271",
        email: "Contact through main office",
        keywords: ["admissions", "marketing", "dean", "enrollment", "gabriela", "morales"]
      }
    ];

    await db.insert(staff).values(pmaStaff);

    console.log("Database seeded successfully");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}