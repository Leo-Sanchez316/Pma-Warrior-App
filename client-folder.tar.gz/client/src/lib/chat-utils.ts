import { apiRequest } from "./queryClient";

export interface ChatResponse {
  text: string;
  location?: {
    name: string;
    address: string;
    hours: string;
    phone: string;
    directions?: string;
  };
  staff?: {
    name: string;
    role: string;
    location: string;
    phone: string;
    email: string;
  };
}

export async function chatWithBot(message: string): Promise<ChatResponse> {
  const response = await apiRequest("POST", "/api/chat", { message });
  return response.json();
}
