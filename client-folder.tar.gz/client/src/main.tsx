import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Register Service Worker for PWA (non-blocking)
if ('serviceWorker' in navigator) {
  // Register immediately without waiting for load event
  navigator.serviceWorker.register('/sw.js')
    .then((registration) => {
      console.log('SW registered: ', registration);
    })
    .catch((registrationError) => {
      console.log('SW registration failed: ', registrationError);
    });
}

// Render app immediately
createRoot(document.getElementById("root")!).render(<App />);
