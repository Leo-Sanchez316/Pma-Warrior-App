import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { User, MapPin, Phone, Mail, Search } from "lucide-react";
import type { Staff } from "@shared/schema";

interface StaffModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectStaff: (staff: Staff) => void;
}

export default function StaffModal({ isOpen, onClose, onSelectStaff }: StaffModalProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: staff = [], isLoading } = useQuery({
    queryKey: ["/api/staff"],
    enabled: isOpen,
  });

  const filteredStaff = staff.filter((member: Staff) =>
    member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStaffColor = (index: number) => {
    const colors = [
      "bg-primary",
      "bg-bot", 
      "bg-amber-500",
      "bg-red-500",
      "bg-purple-500",
      "bg-indigo-500"
    ];
    return colors[index % colors.length];
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-2xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-gray-900">Staff Directory</DialogTitle>
        </DialogHeader>
        
        <div className="mt-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search staff members..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="overflow-y-auto max-h-96 mt-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="text-gray-500">Loading staff directory...</div>
            </div>
          ) : filteredStaff.length === 0 ? (
            <div className="flex items-center justify-center py-8">
              <div className="text-gray-500">
                {searchQuery ? "No staff members found matching your search." : "No staff members available."}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredStaff.map((staffMember: Staff, index: number) => (
                <Button
                  key={staffMember.id}
                  variant="ghost"
                  className="w-full p-4 h-auto bg-gray-50 hover:bg-gray-100 justify-start"
                  onClick={() => onSelectStaff(staffMember)}
                >
                  <div className="flex items-center space-x-4 w-full">
                    <div className={`w-12 h-12 ${getStaffColor(index)} rounded-full flex items-center justify-center flex-shrink-0`}>
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 text-left">
                      <h4 className="font-medium text-gray-900">{staffMember.name}</h4>
                      <p className="text-sm text-gray-600">{staffMember.role}</p>
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <MapPin className="w-3 h-3 mr-2" />
                        <span>{staffMember.location}</span>
                      </div>
                    </div>
                    <div className="text-right text-sm">
                      <p className="text-gray-600">{staffMember.phone || "No phone"}</p>
                      <p className="text-xs text-gray-500">{staffMember.email || "No email"}</p>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
