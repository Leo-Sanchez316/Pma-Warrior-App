import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, Menu, Send, Mic, Bot, User, Clock, Phone, MapPin, Mail } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { chatWithBot } from "@/lib/chat-utils";
import warriorLogo from "@assets/IMG_2341_1749606165751.png";

interface Message {
  id: number;
  text: string;
  isUser: boolean;
  timestamp: Date;
  data?: any;
}

interface ChatAreaProps {
  messages: Message[];
  onAddMessage: (text: string, isUser: boolean, data?: any) => void;
  onClearChat: () => void;
  onToggleSidebar: () => void;
  onQuickMessage: (message: string) => void;
  onShowStaffDirectory: () => void;
  onShowRoomDirectory: () => void;
}

export default function ChatArea({ 
  messages, 
  onAddMessage, 
  onClearChat, 
  onToggleSidebar, 
  onQuickMessage,
  onShowStaffDirectory,
  onShowRoomDirectory 
}: ChatAreaProps) {
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const chatMutation = useMutation({
    mutationFn: chatWithBot,
    onSuccess: (response) => {
      setIsTyping(false);
      onAddMessage(response.text, false, response);
    },
    onError: () => {
      setIsTyping(false);
      onAddMessage("I'm sorry, I'm having trouble processing your request right now. Please try again.", false);
    }
  });

  const sendMessage = async () => {
    const message = inputValue.trim();
    if (!message) return;

    onAddMessage(message, true);
    setInputValue("");
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      chatMutation.mutate(message);
    }, 500 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      sendMessage();
    }
  };

  const mobileQuickActions = [
    { icon: "🚪", text: "Rooms", action: "rooms" },
    { icon: "🍽️", text: "Cafeteria", message: "How do I get to the cafeteria?" },
    { icon: "👔", text: "Principal", message: "Who is the principal?" },
    { icon: "📋", text: "Staff", action: "staff" },
  ];

  return (
    <div className="flex-1 flex flex-col min-h-0">
      {/* Chat Header */}
      <div className="bg-card border-b border-border p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden p-2"
            onClick={onToggleSidebar}
          >
            <Menu className="w-5 h-5 text-muted-foreground" />
          </Button>
          <div className="w-10 h-10 rounded-full flex items-center justify-center overflow-hidden">
            <img 
              src={warriorLogo} 
              alt="Warrior Logo" 
              className="w-8 h-8 object-cover rounded-full"
            />
          </div>
          <div>
            <h2 className="font-medium text-foreground">PMA Warrior</h2>
            <div className="flex items-center text-xs text-muted-foreground">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
              Online - Ready to help
            </div>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="p-2"
          onClick={onClearChat}
        >
          <Trash2 className="w-5 h-5 text-muted-foreground" />
        </Button>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-2 sm:p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex items-start space-x-3 ${
              message.isUser ? "justify-end" : ""
            }`}
          >
            {message.isUser ? (
              <>
                <div className="bg-primary text-white rounded-lg rounded-tr-none p-4 max-w-xs sm:max-w-md">
                  <p className="break-words">{message.text}</p>
                </div>
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-gray-600" />
                </div>
              </>
            ) : (
              <>
                <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 overflow-hidden">
                  <img 
                    src={warriorLogo} 
                    alt="Warrior Logo" 
                    className="w-6 h-6 object-cover rounded-full"
                  />
                </div>
                <div className="bg-bot-light border border-white rounded-lg rounded-tl-none p-4 max-w-xs sm:max-w-md">
                  <p className="text-white break-words">{message.text}</p>
                  
                  {/* Location Information */}
                  {message.data?.location && (
                    <div className="bg-white rounded-lg p-3 border border-emerald-200 mt-3">
                      <div className="flex items-start space-x-3">
                        <MapPin className="w-4 h-4 text-emerald-600 mt-1 flex-shrink-0" />
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 text-sm">{message.data.location.name}</h4>
                          <p className="text-xs text-gray-600 mt-1">{message.data.location.address}</p>
                          <div className="mt-2 text-xs text-gray-500">
                            <div className="flex items-center mb-1">
                              <Clock className="w-3 h-3 mr-2" />
                              <span>{message.data.location.hours}</span>
                            </div>
                            <div className="flex items-center">
                              <Phone className="w-3 h-3 mr-2" />
                              <span>{message.data.location.phone}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      {message.data.location.directions && (
                        <div className="mt-3">
                          <p className="text-sm text-gray-700">
                            <strong>Directions:</strong> {message.data.location.directions}
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Staff Information */}
                  {message.data?.staff && (
                    <div className="bg-white rounded-lg p-3 border border-emerald-200 mt-3">
                      <div className="flex items-start space-x-3">
                        <User className="w-4 h-4 text-emerald-600 mt-1 flex-shrink-0" />
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 text-sm">{message.data.staff.name}</h4>
                          <p className="text-xs text-gray-600 mt-1">{message.data.staff.role}</p>
                          <div className="mt-2 text-xs text-gray-500">
                            <div className="flex items-center mb-1">
                              <MapPin className="w-3 h-3 mr-2" />
                              <span>{message.data.staff.location}</span>
                            </div>
                            <div className="flex items-center mb-1">
                              <Phone className="w-3 h-3 mr-2" />
                              <span>{message.data.staff.phone}</span>
                            </div>
                            <div className="flex items-center">
                              <Mail className="w-3 h-3 mr-2" />
                              <span>{message.data.staff.email}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Quick Actions for Welcome Message */}
                  {message.id === 1 && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="px-3 py-1 h-auto text-xs bg-black border-white text-white hover:bg-gray-800"
                        onClick={() => onQuickMessage("Show me around")}
                      >
                        Show me around
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="px-3 py-1 h-auto text-xs bg-black border-white text-white hover:bg-gray-800"
                        onClick={() => onQuickMessage("Find staff")}
                      >
                        Find staff
                      </Button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        ))}

        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 overflow-hidden">
              <img 
                src={warriorLogo} 
                alt="Warrior Logo" 
                className="w-6 h-6 object-cover rounded-full"
              />
            </div>
            <div className="bg-bot-light border border-emerald-200 rounded-lg rounded-tl-none p-4">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="bg-card border-t border-border p-2 sm:p-4">
        <div className="flex space-x-3">
          <div className="flex-1 relative">
            <Input
              type="text"
              placeholder="Ask me about locations or staff members..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              className="pr-12 bg-input text-foreground placeholder:text-muted-foreground border-border"
            />
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 h-auto text-muted-foreground hover:text-primary"
            >
              <Mic className="w-4 h-4" />
            </Button>
          </div>
          <Button
            onClick={sendMessage}
            disabled={!inputValue.trim() || chatMutation.isPending}
            className="px-6 py-3"
          >
            <Send className="w-4 h-4 mr-2" />
            <span className="hidden sm:block">Send</span>
          </Button>
        </div>

        {/* Quick Suggestions (Mobile) */}
        <div className="lg:hidden mt-3">
          <div className="flex space-x-1 pb-2">
            {mobileQuickActions.map((action, index) => (
              <Button
                key={index}
                variant="secondary"
                size="sm"
                className="flex-1 px-2 py-2 h-auto text-xs bg-muted text-foreground hover:bg-muted/80"
                onClick={() => {
                  if (action.action === "staff") {
                    onShowStaffDirectory();
                  } else if (action.action === "rooms") {
                    onShowRoomDirectory();
                  } else {
                    onQuickMessage(action.message!);
                  }
                }}
              >
                <span className="mr-2">{action.icon}</span>
                {action.text}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
