import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { DoorOpen, Search, MapPin } from "lucide-react";

interface Room {
  number: string;
  floor: string;
  building: string;
  description: string;
}

interface RoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRoom: (roomNumber: string) => void;
}

export default function RoomModal({ isOpen, onClose, onSelectRoom }: RoomModalProps) {
  const [searchTerm, setSearchTerm] = useState("");

  const rooms: Room[] = [
    // 1st Floor Odd Wing
    { number: "101", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Main Office & Principal's Office" },
    { number: "103", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "105", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "107", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "109", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "111", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "113", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "115", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Nurse's Office" },
    { number: "117", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "119", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "121", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Computer Lab" },
    { number: "123", floor: "1st Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    
    // 1st Floor Even Wing
    { number: "102", floor: "1st Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "104", floor: "1st Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "106", floor: "1st Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "108", floor: "1st Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "110", floor: "1st Floor", building: "Main Building - Even Wing", description: "Counseling Office" },
    { number: "112", floor: "1st Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "114", floor: "1st Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "116", floor: "1st Floor", building: "Main Building - Even Wing", description: "Science Lab" },
    { number: "118", floor: "1st Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "120", floor: "1st Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "122", floor: "1st Floor", building: "Main Building - Even Wing", description: "Art Room" },
    { number: "124", floor: "1st Floor", building: "Main Building - Even Wing", description: "Classroom" },
    
    // 2nd Floor Odd Wing
    { number: "201", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "203", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "205", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "207", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "209", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "211", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "213", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Science Lab" },
    { number: "215", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "217", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "219", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Computer Lab" },
    { number: "221", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    { number: "223", floor: "2nd Floor", building: "Main Building - Odd Wing", description: "Classroom" },
    
    // 2nd Floor Even Wing
    { number: "202", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "204", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "206", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "208", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "210", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "212", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "214", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Science Lab" },
    { number: "216", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "218", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "220", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Classroom" },
    { number: "222", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Faculty Office" },
    { number: "224", floor: "2nd Floor", building: "Main Building - Even Wing", description: "Storage/Resource Room" },
    
    // Special Facilities (Outside main building)
    { number: "Cafeteria", floor: "1st Floor", building: "Connected to Gymnasium", description: "Dining Hall & Kitchen" },
    { number: "Gymnasium", floor: "1st Floor", building: "Connected to Cafeteria", description: "Sports & Assembly Hall" },
    { number: "Theatre", floor: "1st Floor", building: "Connected to Gymnasium", description: "Performing Arts Center" },
    { number: "Chapel", floor: "1st Floor", building: "Separate Building", description: "Prayer & Worship Space" },
  ];

  const filteredRooms = rooms.filter((room: Room) =>
    room.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    room.floor.toLowerCase().includes(searchTerm.toLowerCase()) ||
    room.building.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRoomSelect = (roomNumber: string) => {
    onSelectRoom(`Where is room ${roomNumber}?`);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] bg-card border-border">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-foreground">
            <DoorOpen className="w-5 h-5 text-primary" />
            Room Directory
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex flex-col space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search rooms by number, floor, or building..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-background border-border text-foreground"
            />
          </div>

          {/* Room List */}
          <div className="overflow-y-auto max-h-96 space-y-2">
            {filteredRooms.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No rooms found matching your search.
              </div>
            ) : (
              <>
                {/* 1st Floor Odd Wing Section */}
                <div className="mb-4">
                  <h3 className="text-sm font-semibold text-foreground mb-2 px-2">1st Floor - Odd Wing (101, 103, 105...)</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {filteredRooms
                      .filter(room => room.floor === "1st Floor" && room.building.includes("Odd Wing"))
                      .map((room: Room, index: number) => (
                        <Button
                          key={index}
                          variant="ghost"
                          className="flex items-center justify-between p-3 h-auto bg-muted hover:bg-muted/80 text-left"
                          onClick={() => handleRoomSelect(room.number)}
                        >
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                              <span className="text-sm font-medium text-primary">{room.number}</span>
                            </div>
                            <div>
                              <div className="font-medium text-foreground">Room {room.number}</div>
                              <div className="text-xs text-muted-foreground">Odd Wing</div>
                            </div>
                          </div>
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                        </Button>
                      ))}
                  </div>
                </div>

                {/* 1st Floor Even Wing Section */}
                <div className="mb-4">
                  <h3 className="text-sm font-semibold text-foreground mb-2 px-2">1st Floor - Even Wing (102, 104, 106...)</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {filteredRooms
                      .filter(room => room.floor === "1st Floor" && room.building.includes("Even Wing"))
                      .map((room: Room, index: number) => (
                        <Button
                          key={index}
                          variant="ghost"
                          className="flex items-center justify-between p-3 h-auto bg-muted hover:bg-muted/80 text-left"
                          onClick={() => handleRoomSelect(room.number)}
                        >
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                              <span className="text-sm font-medium text-primary">{room.number}</span>
                            </div>
                            <div>
                              <div className="font-medium text-foreground">Room {room.number}</div>
                              <div className="text-xs text-muted-foreground">Even Wing</div>
                            </div>
                          </div>
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                        </Button>
                      ))}
                  </div>
                </div>

                {/* 2nd Floor Odd Wing Section */}
                <div className="mb-4">
                  <h3 className="text-sm font-semibold text-foreground mb-2 px-2">2nd Floor - Odd Wing (201, 203, 205...)</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {filteredRooms
                      .filter(room => room.floor === "2nd Floor" && room.building.includes("Odd Wing"))
                      .map((room: Room, index: number) => (
                        <Button
                          key={index}
                          variant="ghost"
                          className="flex items-center justify-between p-3 h-auto bg-muted hover:bg-muted/80 text-left"
                          onClick={() => handleRoomSelect(room.number)}
                        >
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                              <span className="text-sm font-medium text-primary">{room.number}</span>
                            </div>
                            <div>
                              <div className="font-medium text-foreground">Room {room.number}</div>
                              <div className="text-xs text-muted-foreground">Odd Wing</div>
                            </div>
                          </div>
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                        </Button>
                      ))}
                  </div>
                </div>

                {/* 2nd Floor Even Wing Section */}
                <div className="mb-4">
                  <h3 className="text-sm font-semibold text-foreground mb-2 px-2">2nd Floor - Even Wing (202, 204, 206...)</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {filteredRooms
                      .filter(room => room.floor === "2nd Floor" && room.building.includes("Even Wing"))
                      .map((room: Room, index: number) => (
                        <Button
                          key={index}
                          variant="ghost"
                          className="flex items-center justify-between p-3 h-auto bg-muted hover:bg-muted/80 text-left"
                          onClick={() => handleRoomSelect(room.number)}
                        >
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                              <span className="text-sm font-medium text-primary">{room.number}</span>
                            </div>
                            <div>
                              <div className="font-medium text-foreground">Room {room.number}</div>
                              <div className="text-xs text-muted-foreground">Even Wing</div>
                            </div>
                          </div>
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                        </Button>
                      ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}