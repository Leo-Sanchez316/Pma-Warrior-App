import { Button } from "@/components/ui/button";
import { GraduationCap, Book, Utensils, UserRoundCheck, Heart, BookUser, Clock, MapPin, DoorOpen } from "lucide-react";
import warriorLogo from "@assets/IMG_2341_1749606165751.png";

interface ChatSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onQuickMessage: (message: string) => void;
  onShowStaffDirectory: () => void;
  onShowRoomDirectory: () => void;
}

export default function ChatSidebar({ isOpen, onClose, onQuickMessage, onShowStaffDirectory, onShowRoomDirectory }: ChatSidebarProps) {
  const quickActions = [
    { icon: DoorOpen, text: "Show me room numbers", action: "rooms" },
    { icon: Utensils, text: "How do I get to the cafeteria?", message: "How do I get to the cafeteria?" },
    { icon: UserRoundCheck, text: "Who is the principal?", message: "Who is the principal?" },
    { icon: Heart, text: "Where can I find the counselor?", message: "Where can I find the counselor?" },
  ] as Array<{ icon: any; text: string; action?: string; message?: string }>;

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-50 w-80 bg-card border-r border-border flex flex-col transform transition-transform duration-200 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        ${isOpen ? 'block' : 'hidden lg:flex'}
      `}>
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center overflow-hidden">
              <img 
                src={warriorLogo} 
                alt="Warrior Logo" 
                className="w-8 h-8 object-cover rounded-full"
              />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-foreground">PMA Warrior</h1>
              <p className="text-sm text-muted-foreground">Your Personal Assistant</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="p-6">
          <h2 className="text-sm font-medium text-foreground mb-4">Quick Questions</h2>
          <div className="space-y-2">
            {quickActions.map((action, index) => (
              <Button
                key={index}
                variant="ghost"
                className="w-full justify-start p-3 h-auto bg-muted hover:bg-muted/80 text-foreground"
                onClick={() => {
                  if (action.action === "rooms") {
                    onShowRoomDirectory();
                  } else {
                    onQuickMessage(action.message);
                  }
                }}
              >
                <action.icon className="w-4 h-4 mr-2 text-primary" />
                {action.text}
              </Button>
            ))}
            <Button
              variant="ghost"
              className="w-full justify-start p-3 h-auto bg-muted hover:bg-muted/80 text-foreground"
              onClick={onShowStaffDirectory}
            >
              <BookUser className="w-4 h-4 mr-2 text-primary" />
              View staff directory
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start p-3 h-auto bg-muted hover:bg-muted/80 text-foreground"
              onClick={onShowRoomDirectory}
            >
              <DoorOpen className="w-4 h-4 mr-2 text-primary" />
              View room directory
            </Button>
          </div>
        </div>

        {/* Campus Info */}
        <div className="p-6 border-t border-border mt-auto">
          <div className="bg-primary-light p-4 rounded-lg">
            <h3 className="text-sm font-medium text-primary mb-2">Need more help?</h3>
            <p className="text-xs text-muted-foreground mb-3">Visit the main office for additional assistance.</p>
            <div className="text-xs text-muted-foreground">
              <div className="flex items-center mb-1">
                <Clock className="w-3 h-3 mr-2" />
                Mon-Fri: 8:00 AM - 4:00 PM
              </div>
              <div className="flex items-center">
                <MapPin className="w-3 h-3 mr-2" />
                Building A, Room 101
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
