import { useState } from "react";
import ChatSidebar from "@/components/chat-sidebar";
import ChatArea from "@/components/chat-area";
import StaffModal from "@/components/staff-modal";
import RoomModal from "@/components/room-modal";

export default function ChatPage() {
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [isRoomModalOpen, setIsRoomModalOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hi! I'm PMA Warrior, your personal assistant. I can help you find locations around school and information about staff members. What would you like to know?",
      isUser: false,
      timestamp: new Date(),
      data: null
    }
  ]);

  const addMessage = (text: string, isUser: boolean, data: any = null) => {
    const newMessage = {
      id: Date.now(),
      text,
      isUser,
      timestamp: new Date(),
      data
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const clearChat = () => {
    setMessages([
      {
        id: 1,
        text: "Hi! I'm PMA Warrior, your personal assistant. I can help you find locations around school and information about staff members. What would you like to know?",
        isUser: false,
        timestamp: new Date(),
        data: null
      }
    ]);
  };

  const sendQuickMessage = (question: string) => {
    addMessage(question, true);
    // Trigger bot response for quick messages
    setTimeout(() => {
      import("@/lib/chat-utils").then(({ chatWithBot }) => {
        chatWithBot(question).then((response) => {
          addMessage(response.text, false, response);
        }).catch(() => {
          addMessage("I'm sorry, I'm having trouble processing your request right now. Please try again.", false);
        });
      });
    }, 500);
  };

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden">
      <ChatSidebar 
        isOpen={isMobileSidebarOpen}
        onClose={() => setIsMobileSidebarOpen(false)}
        onQuickMessage={sendQuickMessage}
        onShowStaffDirectory={() => setIsStaffModalOpen(true)}
        onShowRoomDirectory={() => setIsRoomModalOpen(true)}
      />
      
      <ChatArea 
        messages={messages}
        onAddMessage={addMessage}
        onClearChat={clearChat}
        onToggleSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        onQuickMessage={sendQuickMessage}
        onShowStaffDirectory={() => setIsStaffModalOpen(true)}
        onShowRoomDirectory={() => setIsRoomModalOpen(true)}
      />

      <StaffModal 
        isOpen={isStaffModalOpen}
        onClose={() => setIsStaffModalOpen(false)}
        onSelectStaff={(staff) => {
          setIsStaffModalOpen(false);
          sendQuickMessage(`Tell me about ${staff.name}`);
        }}
      />

      <RoomModal 
        isOpen={isRoomModalOpen}
        onClose={() => setIsRoomModalOpen(false)}
        onSelectRoom={(roomQuery) => {
          setIsRoomModalOpen(false);
          sendQuickMessage(roomQuery);
        }}
      />
    </div>
  );
}
